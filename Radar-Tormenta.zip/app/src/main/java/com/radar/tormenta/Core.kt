package com.radar.tormenta

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.location.Location
import android.location.LocationManager
import android.os.Build
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

// ---------------- preferencias ----------------

object Prefs {
    private fun p(c: Context) = c.getSharedPreferences("radar", Context.MODE_PRIVATE)

    fun alerts(c: Context): Boolean = p(c).getBoolean("alerts", false)
    fun setAlerts(c: Context, v: Boolean) {
        p(c).edit().putBoolean("alerts", v).apply()
    }

    fun setLoc(c: Context, lat: Double, lon: Double) {
        p(c).edit().putString("lat", lat.toString()).putString("lon", lon.toString()).apply()
    }

    fun getLoc(c: Context): Pair<Double, Double>? {
        val la = p(c).getString("lat", null)?.toDoubleOrNull() ?: return null
        val lo = p(c).getString("lon", null)?.toDoubleOrNull() ?: return null
        return Pair(la, lo)
    }

    fun lastAlert(c: Context, key: String): Long = p(c).getLong("a_$key", 0L)
    fun setLastAlert(c: Context, key: String, t: Long) {
        p(c).edit().putLong("a_$key", t).apply()
    }
}

// ---------------- red ----------------

object Net {
    private fun open(url: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 10000
        c.setRequestProperty("User-Agent", "RadarTormenta/1.0")
        return c
    }

    fun text(url: String): String {
        val c = open(url)
        try {
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    fun bytes(url: String): ByteArray? {
        val c = open(url)
        try {
            if (c.responseCode != 200) return null
            return c.inputStream.use { it.readBytes() }
        } finally {
            c.disconnect()
        }
    }
}

// ---------------- radar (Rain Viewer) ----------------

class Frames(val host: String, val paths: List<String>, val times: List<Long>)

class Echo(val anyKm: Double?, val strongKm: Double?)

object Radar {
    fun frames(): Frames {
        val j = JSONObject(Net.text("https://api.rainviewer.com/public/weather-maps.json"))
        val host = j.getString("host")
        val past = j.getJSONObject("radar").getJSONArray("past")
        val paths = ArrayList<String>()
        val times = ArrayList<Long>()
        for (i in 0 until past.length()) {
            val o = past.getJSONObject(i)
            paths.add(o.getString("path"))
            times.add(o.getLong("time"))
        }
        if (paths.isEmpty()) throw Exception("sin cuadros de radar")
        return Frames(host, paths, times)
    }

    /**
     * Busca la lluvia (eco de radar) mas cercana a la ubicacion, dentro de maxKm.
     * anyKm = cualquier lluvia. strongKm = nucleos intensos (colores amarillo/naranja/rojo).
     */
    fun scan(host: String, path: String, lat: Double, lon: Double, maxKm: Double): Echo {
        val z = 7
        val n = 1 shl z
        val world = n * 256.0
        val latRad = Math.toRadians(lat)
        val px = (lon + 180.0) / 360.0 * world
        val py = (1.0 - Math.log(Math.tan(latRad) + 1.0 / Math.cos(latRad)) / Math.PI) / 2.0 * world
        val tx = (px / 256.0).toInt()
        val ty = (py / 256.0).toInt()
        val mpp = 156543.03392 * Math.cos(latRad) / n
        val maxPx = maxKm * 1000.0 / mpp

        var any = Double.MAX_VALUE
        var strong = Double.MAX_VALUE
        val buf = IntArray(256 * 256)

        for (dx in -1..1) {
            for (dy in -1..1) {
                val x = tx + dx
                val y = ty + dy
                if (y < 0 || y >= n) continue
                val xx = ((x % n) + n) % n
                val data = Net.bytes("$host$path/256/$z/$xx/$y/2/1_1.png") ?: continue
                val bmp = BitmapFactory.decodeByteArray(data, 0, data.size) ?: continue
                if (bmp.width != 256 || bmp.height != 256) {
                    bmp.recycle()
                    continue
                }
                bmp.getPixels(buf, 0, 256, 0, 0, 256, 256)
                bmp.recycle()
                val ox = x * 256.0
                val oy = y * 256.0
                for (j in 0 until 256) {
                    for (i in 0 until 256) {
                        val p = buf[j * 256 + i]
                        val a = p ushr 24
                        if (a < 40) continue
                        val d = Math.hypot(ox + i + 0.5 - px, oy + j + 0.5 - py)
                        if (d > maxPx) continue
                        val km = d * mpp / 1000.0
                        if (km < any) any = km
                        val r = (p shr 16) and 255
                        val b = p and 255
                        if (a > 100 && r > 200 && b < 120 && km < strong) strong = km
                    }
                }
            }
        }
        return Echo(
            if (any == Double.MAX_VALUE) null else any,
            if (strong == Double.MAX_VALUE) null else strong
        )
    }
}

// ---------------- clima y viento (Open-Meteo) ----------------

class Wx(
    val temp: Double,
    val speed: Double,
    val gust: Double,
    val dir: Int,
    val stormSoon: Boolean,
    val gustMax: Double
)

object Weather {
    fun fetch(lat: Double, lon: Double): Wx {
        val url = "https://api.open-meteo.com/v1/forecast?latitude=" +
            String.format(Locale.US, "%.4f", lat) + "&longitude=" + String.format(Locale.US, "%.4f", lon) +
            "&current=temperature_2m,wind_speed_10m,wind_direction_10m,wind_gusts_10m" +
            "&hourly=weather_code,wind_gusts_10m&forecast_hours=4&wind_speed_unit=kmh&timezone=auto"
        val j = JSONObject(Net.text(url))
        val cur = j.getJSONObject("current")
        val hr = j.getJSONObject("hourly")
        val codes = hr.getJSONArray("weather_code")
        val gusts = hr.getJSONArray("wind_gusts_10m")
        var storm = false
        for (i in 0 until codes.length()) {
            if (!codes.isNull(i) && codes.getInt(i) >= 95) storm = true
        }
        var gm = cur.getDouble("wind_gusts_10m")
        for (i in 0 until gusts.length()) {
            if (!gusts.isNull(i)) gm = maxOf(gm, gusts.getDouble(i))
        }
        return Wx(
            cur.getDouble("temperature_2m"),
            cur.getDouble("wind_speed_10m"),
            cur.getDouble("wind_gusts_10m"),
            cur.getDouble("wind_direction_10m").roundToInt(),
            storm,
            gm
        )
    }
}

// ---------------- analisis y avisos ----------------

/** level: 0 despejado, 1 llueve/lluvia cerca, 2 se acerca lluvia, 3 se acerca tormenta */
class Analysis(val level: Int, val text: String)

object Alerts {

    fun analyze(fr: Frames, lat: Double, lon: Double): Analysis {
        val last = fr.paths.size - 1
        val prevIdx = maxOf(0, last - 3)
        val now = Radar.scan(fr.host, fr.paths[last], lat, lon, 90.0)
        val prev = if (prevIdx < last) Radar.scan(fr.host, fr.paths[prevIdx], lat, lon, 90.0) else null
        val dtH = if (prev != null) (fr.times[last] - fr.times[prevIdx]) / 3600.0 else 0.0

        val anyNow = now.anyKm
        val strongNow = now.strongKm

        fun speed(cur: Double?, before: Double?): Double? {
            if (cur == null || before == null || dtH <= 0.0) return null
            return (before - cur) / dtH
        }

        fun approaching(cur: Double?, before: Double?): Boolean {
            if (cur == null) return false
            if (before == null) return prev != null
            val v = speed(cur, before) ?: return false
            return v > 8.0
        }

        fun eta(cur: Double?, before: Double?): String {
            val v = speed(cur, before) ?: return ""
            if (cur == null || v <= 8.0 || cur <= 1.5) return ""
            val m = (cur / v * 60.0).roundToInt()
            return if (m in 1..180) " · llegaría en unos $m min" else ""
        }

        if (strongNow != null && strongNow <= 50.0 && approaching(strongNow, prev?.strongKm)) {
            return Analysis(
                3,
                "Se acerca una tormenta: núcleo intenso a ${strongNow.roundToInt()} km" + eta(strongNow, prev?.strongKm)
            )
        }
        if (anyNow != null && anyNow <= 1.5) {
            val t = if (strongNow != null && strongNow <= 1.5) "Lluvia intensa sobre tu ubicación" else "Está lloviendo sobre tu ubicación"
            return Analysis(1, t)
        }
        if (anyNow != null && anyNow <= 40.0 && approaching(anyNow, prev?.anyKm)) {
            return Analysis(2, "Se acerca lluvia: a ${anyNow.roundToInt()} km" + eta(anyNow, prev?.anyKm))
        }
        if (anyNow != null && anyNow <= 40.0) {
            return Analysis(1, "Lluvia a ${anyNow.roundToInt()} km, sin acercarse")
        }
        return Analysis(0, "Sin lluvia a menos de 40 km")
    }

    /** Lo usa el aviso en segundo plano. */
    fun runCheck(c: Context, lat: Double, lon: Double) {
        val fr = Radar.frames()
        val a = analyze(fr, lat, lon)
        val w = try {
            Weather.fetch(lat, lon)
        } catch (e: Exception) {
            null
        }
        if (a.level == 3) {
            once(c, "storm", 45, "Se acerca una tormenta", a.text)
        } else if (a.level == 2) {
            once(c, "rain", 90, "Se acerca lluvia", a.text)
        }
        if (w != null) {
            if (w.stormSoon && a.level < 3) {
                once(c, "thunder", 180, "Tormenta prevista", "Hay tormenta eléctrica en el pronóstico de las próximas horas.")
            }
            if (w.gustMax >= 60.0) {
                once(c, "gust", 120, "Ráfagas fuertes", "Se esperan ráfagas de hasta ${w.gustMax.roundToInt()} km/h.")
            }
        }
    }

    private fun once(c: Context, key: String, cooldownMin: Int, title: String, text: String) {
        val last = Prefs.lastAlert(c, key)
        val now = System.currentTimeMillis()
        if (now - last < cooldownMin * 60000L) return
        Prefs.setLastAlert(c, key, now)
        Notif.show(c, key.hashCode(), title, text)
    }
}

// ---------------- notificaciones, ubicacion, tareas ----------------

object Notif {
    const val CH = "avisos"

    fun show(c: Context, id: Int, title: String, text: String) {
        if (Build.VERSION.SDK_INT >= 33 &&
            c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Avisos de tormenta", NotificationManager.IMPORTANCE_HIGH))
        val pi = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(c, CH)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        nm.notify(id, n)
    }
}

object Loc {
    fun best(c: Context): Pair<Double, Double>? {
        val fine = c.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = c.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fine && !coarse) return null
        return try {
            val lm = c.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            var b: Location? = null
            for (p in lm.getProviders(true)) {
                val l = lm.getLastKnownLocation(p) ?: continue
                if (b == null || l.time > b.time) b = l
            }
            b?.let { Pair(it.latitude, it.longitude) }
        } catch (e: Exception) {
            null
        }
    }
}

object Work {
    fun enable(c: Context) {
        val req = PeriodicWorkRequestBuilder<CheckWorker>(15, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(c).enqueueUniquePeriodicWork("check", ExistingPeriodicWorkPolicy.UPDATE, req)
    }

    fun disable(c: Context) {
        WorkManager.getInstance(c).cancelUniqueWork("check")
    }
}

class CheckWorker(c: Context, p: WorkerParameters) : Worker(c, p) {
    override fun doWork(): Result {
        val ctx = applicationContext
        if (!Prefs.alerts(ctx)) return Result.success()
        val fresh = Loc.best(ctx)
        if (fresh != null) Prefs.setLoc(ctx, fresh.first, fresh.second)
        val loc = Prefs.getLoc(ctx) ?: return Result.success()
        try {
            Alerts.runCheck(ctx, loc.first, loc.second)
        } catch (e: Exception) {
        }
        return Result.success()
    }
}
