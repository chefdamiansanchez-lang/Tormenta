package com.radar.tormenta

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.roundToInt

class MainActivity : Activity() {

    private val BG = 0xFF232833.toInt()
    private val SURFACE = 0xFF2E3441.toInt()
    private val SURFACE2 = 0xFF3A4252.toInt()
    private val ACCENT = 0xFF9CCBB8.toInt()
    private val INK = 0xFFE9EDF2.toInt()
    private val MUTED = 0xFF9AA4B2.toInt()
    private val WARN = 0xFFE8CE9C.toInt()
    private val DANGER = 0xFFE8A0A0.toInt()

    private lateinit var web: WebView
    private lateinit var arrow: TextView
    private lateinit var windTv: TextView
    private lateinit var subTv: TextView
    private lateinit var statusTv: TextView
    private lateinit var playBtn: Button
    private lateinit var lm: LocationManager

    private val ui = Handler(Looper.getMainLooper())
    private var pageReady = false
    private val pending = ArrayList<String>()
    private var hasLoc = false
    private var lat = 0.0
    private var lon = 0.0
    private var lastFetchLat = 999.0
    private var lastFetchLon = 999.0
    private var playing = true

    private val refresh = object : Runnable {
        override fun run() {
            doRefresh()
            ui.postDelayed(this, 5 * 60 * 1000L)
        }
    }

    private val locListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            onLoc(location)
        }

        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}

        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        lm = getSystemService(LOCATION_SERVICE) as LocationManager
        buildUi()
        requestNeeded()
        if (Prefs.alerts(this)) Work.enable(this)
    }

    // ---------- interfaz ----------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, r: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(r).toFloat()
        return g
    }

    private fun smallButton(text: String): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.textSize = 13f
        b.maxLines = 1
        b.setTextColor(INK)
        b.background = rounded(SURFACE2, 16)
        b.stateListAnimator = null
        return b
    }

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(BG)

        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.setBackgroundColor(BG)
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                pageReady = true
                for (s in pending) web.evaluateJavascript(s, null)
                pending.clear()
            }
        }
        web.loadUrl("file:///android_asset/map.html")
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.setPadding(dp(16), dp(14), dp(16), dp(10))
        val bgPanel = GradientDrawable()
        bgPanel.setColor(SURFACE)
        val r = dp(22).toFloat()
        bgPanel.cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        panel.background = bgPanel

        // viento
        val windRow = LinearLayout(this)
        windRow.orientation = LinearLayout.HORIZONTAL
        windRow.gravity = Gravity.CENTER_VERTICAL

        arrow = TextView(this)
        arrow.text = "↑"
        arrow.textSize = 38f
        arrow.setTextColor(ACCENT)
        arrow.gravity = Gravity.CENTER
        windRow.addView(arrow, LinearLayout.LayoutParams(dp(56), dp(56)))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(12), 0, 0, 0)
        windTv = TextView(this)
        windTv.text = "Viento: buscando…"
        windTv.textSize = 18f
        windTv.setTextColor(INK)
        subTv = TextView(this)
        subTv.text = ""
        subTv.textSize = 14f
        subTv.setTextColor(MUTED)
        col.addView(windTv)
        col.addView(subTv)
        windRow.addView(col)
        panel.addView(windRow)

        statusTv = TextView(this)
        statusTv.text = "Buscando tu ubicación…"
        statusTv.textSize = 16f
        statusTv.setTextColor(MUTED)
        statusTv.setPadding(0, dp(8), 0, dp(4))
        panel.addView(statusTv)

        val sw = Switch(this)
        sw.text = "Avisarme si se acerca una tormenta"
        sw.textSize = 15f
        sw.setTextColor(INK)
        sw.isChecked = Prefs.alerts(this)
        sw.setOnCheckedChangeListener { _, on ->
            Prefs.setAlerts(this, on)
            if (on) {
                Work.enable(this)
                askBackground()
            } else {
                Work.disable(this)
            }
        }
        panel.addView(sw, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)))

        val btnRow = LinearLayout(this)
        btnRow.orientation = LinearLayout.HORIZONTAL
        playBtn = smallButton("⏸ Pausa")
        val centerBtn = smallButton("📍 Centrar")
        val testBtn = smallButton("🔔 Probar")
        for (b in listOf(playBtn, centerBtn, testBtn)) {
            val lp = LinearLayout.LayoutParams(0, dp(46), 1f)
            lp.setMargins(dp(3), dp(4), dp(3), dp(4))
            btnRow.addView(b, lp)
        }
        panel.addView(btnRow)

        val credit = TextView(this)
        credit.text = "Radar: Rain Viewer · Viento: Open-Meteo"
        credit.textSize = 11f
        credit.setTextColor(MUTED)
        credit.gravity = Gravity.CENTER
        panel.addView(credit, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        root.addView(panel, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(root)

        playBtn.setOnClickListener {
            playing = !playing
            js("togglePlay()")
            playBtn.text = if (playing) "⏸ Pausa" else "▶ Play"
        }
        centerBtn.setOnClickListener { js("center()") }
        testBtn.setOnClickListener {
            Notif.show(this, 1, "Aviso de prueba", "Si ves esto, los avisos funcionan.")
            Toast.makeText(this, "Aviso de prueba enviado", Toast.LENGTH_SHORT).show()
        }
    }

    private fun js(code: String) {
        ui.post {
            if (pageReady) web.evaluateJavascript(code, null) else pending.add(code)
        }
    }

    // ---------- permisos y ubicacion ----------

    private fun has(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun requestNeeded() {
        val need = ArrayList<String>()
        if (!has(Manifest.permission.ACCESS_FINE_LOCATION)) need.add(Manifest.permission.ACCESS_FINE_LOCATION)
        if (!has(Manifest.permission.ACCESS_COARSE_LOCATION)) need.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33 && !has(Manifest.permission.POST_NOTIFICATIONS)) {
            need.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1) startLocation()
    }

    private fun askBackground() {
        if (Build.VERSION.SDK_INT >= 29 &&
            has(Manifest.permission.ACCESS_FINE_LOCATION) &&
            !has(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
        ) {
            AlertDialog.Builder(this)
                .setTitle("Avisos con la app cerrada")
                .setMessage("Para avisarte aunque la app esté cerrada, elegí \"Permitir todo el tiempo\" en el permiso de ubicación.")
                .setPositiveButton("Continuar") { _, _ ->
                    requestPermissions(arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION), 2)
                }
                .setNegativeButton("Ahora no", null)
                .show()
        }
    }

    private fun startLocation() {
        if (!has(Manifest.permission.ACCESS_FINE_LOCATION) && !has(Manifest.permission.ACCESS_COARSE_LOCATION)) {
            statusTv.text = "Activá el permiso de ubicación para ver el radar en tu posición"
            return
        }
        for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
            try {
                if (lm.isProviderEnabled(p)) {
                    val last = lm.getLastKnownLocation(p)
                    if (last != null) onLoc(last)
                    lm.requestLocationUpdates(p, 4000L, 5f, locListener)
                }
            } catch (e: Exception) {
            }
        }
    }

    private fun stopLocation() {
        try {
            lm.removeUpdates(locListener)
        } catch (e: Exception) {
        }
    }

    private fun onLoc(l: Location) {
        lat = l.latitude
        lon = l.longitude
        val first = !hasLoc
        hasLoc = true
        Prefs.setLoc(this, lat, lon)
        js("setPos($lat,$lon,${l.accuracy})")
        val res = FloatArray(1)
        Location.distanceBetween(lastFetchLat, lastFetchLon, lat, lon, res)
        if (first || res[0] > 3000f) doRefresh()
    }

    override fun onResume() {
        super.onResume()
        startLocation()
        ui.removeCallbacks(refresh)
        ui.post(refresh)
    }

    override fun onPause() {
        ui.removeCallbacks(refresh)
        stopLocation()
        super.onPause()
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }

    // ---------- datos ----------

    private fun doRefresh() {
        val la = lat
        val lo = lon
        val ok = hasLoc
        if (ok) {
            lastFetchLat = la
            lastFetchLon = lo
        }
        Thread {
            var fr: Frames? = null
            try {
                val f = Radar.frames()
                fr = f
                val n = f.paths.size
                val from = maxOf(0, n - 6)
                val o = JSONObject()
                    .put("host", f.host)
                    .put("paths", JSONArray(f.paths.subList(from, n)))
                    .put("times", JSONArray(f.times.subList(from, n)))
                js("setFrames($o)")
            } catch (e: Exception) {
            }
            if (ok) {
                val a = try {
                    fr?.let { Alerts.analyze(it, la, lo) }
                } catch (e: Exception) {
                    null
                }
                val w = try {
                    Weather.fetch(la, lo)
                } catch (e: Exception) {
                    null
                }
                ui.post { showStatus(a, w) }
            }
        }.start()
    }

    private fun compass(dir: Int): String {
        val names = arrayOf("N", "NE", "E", "SE", "S", "SO", "O", "NO")
        return names[((dir + 22.5) / 45.0).toInt() % 8]
    }

    private fun showStatus(a: Analysis?, w: Wx?) {
        if (w != null) {
            arrow.rotation = ((w.dir + 180) % 360).toFloat()
            windTv.text = "Viento ${w.speed.roundToInt()} km/h del ${compass(w.dir)}"
            subTv.text = "Ráfagas ${w.gust.roundToInt()} km/h · ${w.temp.roundToInt()}°C"
        } else {
            windTv.text = "Viento no disponible"
        }
        if (a != null) {
            val pre = when (a.level) {
                3 -> "⛈ "
                2 -> "🌧 "
                1 -> "💧 "
                else -> "☀ "
            }
            statusTv.text = pre + a.text
            statusTv.setTextColor(
                when (a.level) {
                    3 -> DANGER
                    2 -> WARN
                    else -> ACCENT
                }
            )
        } else {
            statusTv.text = "Radar no disponible"
            statusTv.setTextColor(MUTED)
        }
    }
}
