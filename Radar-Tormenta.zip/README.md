# Radar Tormenta

Mapa con tu ubicacion y radar de lluvia animado, viento y aviso cuando se acerca una tormenta.

1. Subi todo el contenido al repositorio (incluida la carpeta .github/workflows/build.yml).
2. En Actions se compila solo.
3. El APK queda en Releases.

Datos: radar Rain Viewer, viento y pronostico Open-Meteo, mapa OpenStreetMap/CARTO.
